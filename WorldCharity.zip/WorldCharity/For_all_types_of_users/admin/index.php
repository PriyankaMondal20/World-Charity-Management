<?php 

     require_once("header.php");

?>

<h1 style="color:green;">Administrator Panel<h1/>

<p style="font-size:25px;">For signing in click on Sign in.</p>


<?php 

     require_once("footer.php");

?>

