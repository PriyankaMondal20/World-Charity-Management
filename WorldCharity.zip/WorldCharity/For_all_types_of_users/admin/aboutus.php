<!doctype html>
<html>
<head>
	<title>Layout Design</title>
	<link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
	<div class="wrapper">
		<div class="header">
			<h1>Welcome My Fist Website</h1>		
		</div>
		<div class="navbar">
			<ul>
				<li><a href="home.php">Home</a></li>
				
				<li><a href="services.php">Services</a></li>
				<li><a href="aboutus.php">About us</a></li>
				<li><a href="ouraim.php">Our Aim</a></li> 
				
			</ul>
		</div>
		<div class="main">
			<div class="leftbar">Leftbar</div>
			<div class="content">
			
			
<h1 style="color:green;">About Us</h1>
<p style="font-size:18px;" > This charity management system will help NGOs to find donors easily. donors also find ngo easily.In our project (The Online Charity Management System) is a type of non-profit organization to provide a web site implementation of social service for the needy and low income families. We aim to find all charity organizations, browse all their contributions and donate exactly to others who deserve donations. Some charities need financial supports and some charities have surplus and there is a lot of donors who can give financial support but they don’t know about charities’ needs. We proposed to build a charity management system for the distribution of donations between charities. </p>
	
			
			</div>
			<div class="rightbar">Rightbar</div>
			<div style="clear:both;"></div>
		</div>
		<div class="footer">Footer</div>
	</div>
</body>
</html>