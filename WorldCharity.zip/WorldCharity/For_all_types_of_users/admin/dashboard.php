<?php
    
     require_once("header.php");
	
?>


<p style="font-size:18px;"> Welcome to admin panel. To see your all users click on All User button.</p>


<?php
     require_once("footer.php");
?>