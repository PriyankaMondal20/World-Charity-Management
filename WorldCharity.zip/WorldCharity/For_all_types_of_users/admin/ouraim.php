<!doctype html>
<html>
<head>
	<title>Layout Design</title>
	<link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
	<div class="wrapper">
		<div class="header">
			<h1>Welcome My Fist Website</h1>		
		</div>
		<div class="navbar">
			<ul>
				<li><a href="home.php">Home</a></li>
				
				<li><a href="services.php">Services</a></li>
				<li><a href="aboutus.php">About us</a></li>
				<li><a href="ouraim.php">Our Aim</a></li> 
				
			</ul>
		</div>
		<div class="main">
			<div class="leftbar">Leftbar</div>
			<div class="content">
			
<h1  style="color:green;">Our Aim</h1>
<p  style="font-size:18px;">   We try to connect between donar and ngo easily.</p>
			</div>
			<div class="rightbar">Rightbar</div>
			<div style="clear:both;"></div>
		</div>
		<div class="footer">Footer</div>
	</div>
</body>
</html>