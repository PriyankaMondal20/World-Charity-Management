</div>
			<div class="rightbar">Rightbar</div>
			<div style="clear:both;"></div>
		</div>
		<div class="footer">Footer</div>
	</div>
</body>
</html>