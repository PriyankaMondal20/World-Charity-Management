<?php
    
   session_start();
   
   session_destroy();

?>

<script language="Javascript">document.location.href="home.php"</script> 