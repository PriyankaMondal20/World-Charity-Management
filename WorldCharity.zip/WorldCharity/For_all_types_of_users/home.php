<?php
     require_once("header.php");
?>
	 
			
				<h1 style="color:green;" >About Home Page</h1>
				
				<p>
				    Welcome to our website.
				
				</p>
				
			
				
				
				<h1  style="color:green;">About Website</h1>
				<p>
					
				   Our website is for all about charity.
				   
				</p>
			

<?php
     require_once("footer.php");
?>			
			