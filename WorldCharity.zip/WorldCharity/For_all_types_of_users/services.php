<!doctype html>
<html>
<head>
	<title>Layout Design</title>
	<link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
	<div class="wrapper">
		<div class="header">
			<h1>Welcome My Fist Website</h1>		
		</div>
		<div class="navbar">
			<ul>
				<li><a href="home.php">Home</a></li>
				<li><a href="services.php">Services</a></li>
				<li><a href="aboutus.php">About us</a></li>
				<li><a href="ouraim.php">Our Aim</a></li> 
			</ul>
		</div>
		<div class="main">
			<div class="leftbar">Leftbar</div>
			<div class="content">
			
<h1  style="color:green;">Our Services</h1>
<p style="font-size:18px;">NGOs can find donors, can contact with them for the donation and etc. On the other hand Donors also can find NGOs, can condact with them for helping them with the donation and etc. All these purposes can be fulfilled by this one platform. This platform ensures a worldwide service.</p>

			</div>
			<div class="rightbar">Rightbar</div>
			<div style="clear:both;"></div>
		</div>
		<div class="footer">Footer</div>
	</div>
</body>
</html>